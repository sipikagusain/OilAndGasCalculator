﻿import * as React from "react";
import './Layout.css';

const Header = () => {
    return (
        <div>
            <div className="title">
                <h1>Oil And Gas Calculator</h1>
            </div>
        </div>
    );
}

export default Header;
