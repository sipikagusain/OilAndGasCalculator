﻿namespace OilAndGasCalculator.Business.BusinessLogic
{
    public class CommonHelper
    {
        public static T[,] To2D<T>(T[][] source)
        {
            try
            {
                int FirstDim = source.Length;
                int SecondDim = source.GroupBy(row => row.Length).Single().Key; // throws InvalidOperationException if source is not rectangular

                var result = new T[FirstDim, SecondDim];
                for (int i = 0; i < FirstDim; ++i)
                    for (int j = 0; j < SecondDim; ++j)
                        result[i, j] = source[i][j];

                return result;
            }
            catch (InvalidOperationException)
            {
                throw new InvalidOperationException("The given jagged array is not rectangular.");
            }
        }

        public static double[,] GetArrayFromDataPoints(string filePath)
        {
            //var filePath = @"C:\Users\sipika.gusain\Desktop\depthvalues.csv";
            var data = File.ReadLines(filePath).Select(x => x.Split(' ').Select(x => Convert.ToDouble(x)).ToArray()).ToArray();
            return CommonHelper.To2D(data);
        }

        public static double ConvertToDifferentType(double value, string type)
        {
            switch (type)
            {
                case "Feet":
                    return value * 3.28084;
                case "CubicMeter":
                    return value / 35.314667;
                case "Barrel":
                    return value / 5.614583;
            }

            return 0;
        }
    }
}
