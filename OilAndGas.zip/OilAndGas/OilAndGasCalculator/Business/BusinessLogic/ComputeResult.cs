﻿using OilAndGasVolumeCalculator.Business.BusinessModel;
using OilAndGasVolumeCalculator.Business.Interface;
using OilAndGasVolumeCalculator.Common.Implementation;
using OilAndGasVolumeCalculator.Controllers.Models;

namespace OilAndGasVolumeCalculator.Business.BusinessLogic
{
    public class ComputeResult : IComputeResult
    {
        private readonly ILogger<ComputeResult> _logger;

        public ComputeResult(ILogger<ComputeResult> logger)
        {
            _logger = logger;
        }

        public ComputationResult GetVolume(ComputeCalculationRequest computeCalculationRequest)
        {
            try
            {
                var computationResult = new ComputationResult();
                _logger.LogInformation("ComputationResult - GetVolume method has started");
                computationResult = Helper.ComputeVolume(computeCalculationRequest);

                _logger.LogInformation("ComputationResult - GetVolume method has completed");
                return computationResult;
            }
            catch (CustomException ex)
            {
                _logger.LogError($"ComputationResult - GetVolume method has thrown exception due to invalid number");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError($"ComputationResult - GetVolume method has thrown exception - {ex} - {ex.StackTrace}");
                throw;
            }
        }
    }
}
