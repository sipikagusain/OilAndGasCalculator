﻿namespace OilAndGasVolumeCalculator.Business.BusinessModel
{
    public class ComputationResult
    {
        public string? CubicFeetResult { get; set; }

        public string? CubicMeterResult { get; set; }

        public string? BarrelResult { get; set; }
    }
}
