﻿import React, { useState } from 'react';
import './VolumeCalculator.css';

export const VolumeCalculator = () => {
    const [data, setData] = useState({
    });

    const [output, setOutput] = useState({});
    const [isDisabled, setDisabled] = useState(true);
    const [errorMessage, setErrorMessage] = useState("");

    const computeCalculation = async () => {
        const response = await fetch('computeCalculation', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                FilePath: data.filePath,
                GridLength: data.gridLength,
                GridWidth: data.gridWidth,
                GridCellLength: data.gridCellLength,
                GridCellWidth: data.gridCellWidth,
                BottomHorizon: data.bottomHorizon,
                FluidContact: data.fluidContact
            })
        });

        if (response.status === 200) {
            const result = await response.json();
            if (result) {
                var volume =
                {
                    CubicFeetResult: result.cubicFeetResult,
                    BarrelResult: result.barrelResult,
                    CubicMeterResult: result.cubicMeterResult
                }
                setOutput(volume);
            }
        } else if (response.status === 400) {
            setErrorMessage("An Error has occured ! Please try again after some time.");
        }
    }

    const onInput = (event, value) => {
        let updatedData = { ...data };
        updatedData[value] = event.target.value;
        setData(updatedData);

        let disable = (data.filePath == undefined || data.filePath == "")
            || (data.gridLength == undefined || data.gridLength == "")
            || (data.gridWidth == undefined || data.gridWidth == "")
            || (data.gridCellWidth == undefined || data.gridCellWidth == "")
            || (data.gridCellLength == undefined || data.gridCellLength == "")
            || (data.bottomHorizon == undefined || data.bottomHorizon == "")
            || (data.fluidContact == undefined || data.fluidContact == "")

        setDisabled(disable);
    }

    const renderView = () => {
        return (
            <div>
                <div className="number">
                    <span style={{ color: "red" }}>{errorMessage}</span>
                </div>
                <div className="number">
                    Enter File Path : <input type="text" name="filePath" placeholder={"filepath"} size="100" value={data.filePath} onChange={(event) => { onInput(event, "filePath") }} />
                </div>
                <div className="number">
                    Enter Dimesion Length : <input type="text" name="gridLength" placeholder={"26"} size="2" value={data.gridLength} onChange={(event) => { onInput(event, "gridLength") }} />
                </div>
                <div className="number">
                    Enter Dimesion Width : <input type="text" name="gridWidth" placeholder={"16"} size="2" value={data.gridWidth} onChange={(event) => { onInput(event, "gridWidth") }} />
                </div>
                <div className="number">
                    Enter Grid Cell Length(in Feets) : <input type="text" name="gridCellLength" size="2" placeholder={"200"} value={data.gridCellLength} onChange={(event) => { onInput(event, "gridCellLength") }} />
                </div>
                <div className="number">
                    Enter Grid Cell Width(in Feets) : <input type="text" name="gridCellWidth" size="2" placeholder={"200"} value={data.gridCellWidth} onChange={(event) => { onInput(event, "gridCellWidth") }} />
                </div>
                <div className="number">
                    Enter Bottom Horizon value(in Meters) : <input type="text" size="2" name="bottomHorizon" placeholder={"100"} value={data.bottomHorizon} onChange={(event) => { onInput(event, "bottomHorizon") }} />
                </div>
                <div className="number">
                    Enter Fluid Contact (in Meters) : <input type="text" size="2" name="fluidContact" placeholder={"3000"} value={data.fluidContact} onChange={(event) => { onInput(event, "fluidContact") }} />
                </div>
                <div className="compute-button">
                    <button disabled={isDisabled} onClick={() => computeCalculation()} >Compute</button>
                </div>

                <div className="outerBox">
                    The volume of Oil is :
                    <br /> <br />
                    <div className="number">
                        Cubic Feet = <input type="text" size="15" name="gridWidth" value={output.CubicFeetResult} disabled />
                    </div>
                    <div className="number">
                        Cubic Meter = <input type="text" size="15" name="gridWidth" value={output.CubicMeterResult} disabled />
                    </div>
                    <div className="number">
                        Barrels = <input type="text" size="15" name="gridWidth" value={output.BarrelResult} disabled />
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="container">
            <p className="heading"></p>
            {renderView()}
        </div>
    );
}