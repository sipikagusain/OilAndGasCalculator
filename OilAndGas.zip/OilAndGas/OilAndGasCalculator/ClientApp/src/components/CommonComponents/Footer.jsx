﻿import * as React from "react";
import './Layout.css';

const Footer = () => {
    return (
        <div className="footer">
            <div className="Title-Subtitle">A demo project by Sipika Kathuria</div>
        </div>
    );
}

export default Footer;
