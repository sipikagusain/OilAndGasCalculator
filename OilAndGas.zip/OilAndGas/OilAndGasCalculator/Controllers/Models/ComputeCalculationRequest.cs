﻿namespace OilAndGasVolumeCalculator.Controllers.Models
{
    public class ComputeCalculationRequest
    {
        public string FilePath { get; set; }
        public string GridLength { get; set; }
        public string GridWidth { get; set; }
        public string BottomHorizon { get; set; }
        public string GridCellLength { get; set; }
        public string GridCellWidth { get; set; }
        public string FluidContact { get; set; }        
    }
}
