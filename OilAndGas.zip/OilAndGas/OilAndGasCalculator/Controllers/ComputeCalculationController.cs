﻿using Microsoft.AspNetCore.Mvc;
using OilAndGasVolumeCalculator.Business.Interface;
using OilAndGasVolumeCalculator.Common.Implementation;
using OilAndGasVolumeCalculator.Controllers.Models;
using System.Net;

namespace OilAndGasVolumeCalculator.Controllers
{
    /// <summary>
    /// This class can compute the calculation of OilAndGasVolume
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class ComputeCalculationController : ControllerBase
    {
        private readonly ILogger<ComputeCalculationController> _logger;
        private readonly IComputeResult _computeResult;

        public ComputeCalculationController(ILogger<ComputeCalculationController> logger,
            IComputeResult computeResult)
        {
            _logger = logger;
            _computeResult = computeResult;
        }

        [HttpPost]
        public ActionResult Get([FromBody] ComputeCalculationRequest computeCalculationRequest)
        {
            try
            {
                _logger.LogInformation("Computation to Volume has started");
                var result = _computeResult.GetVolume(computeCalculationRequest);
                _logger.LogInformation("Computation to Volume has completed");
                return Ok(result);
            }
            catch (CustomException ex)
            {
                _logger.LogInformation($"ComputationResult  method has thrown exception due to invalid number");
                var exception = new BadHttpRequestException(ex.Message, (int)HttpStatusCode.InternalServerError);
                return BadRequest(exception);
            }
            catch (Exception ex)
            {
                _logger.LogError("ComputeCalculationController -  Get failed due to" + ex.Message + ex.StackTrace);
                return BadRequest("An error has occurred while calculation");
            }
        }
    }
}