﻿using OilAndGasVolumeCalculator.Common.Interface;

namespace OilAndGasVolumeCalculator.Common.Implementation
{
    [Serializable]
    public class CustomException : Exception, ICustomException
    {
        public CustomException()
        {

        }

        public CustomException(string message)
        : base(message)
        { }

        public CustomException(string message, Exception innerException)
            : base(message, innerException)
        { }

    }
}
