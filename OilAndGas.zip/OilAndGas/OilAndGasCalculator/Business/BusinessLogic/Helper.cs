﻿using OilAndGasCalculator.Business.BusinessLogic;
using OilAndGasVolumeCalculator.Business.BusinessModel;
using OilAndGasVolumeCalculator.Controllers.Models;

namespace OilAndGasVolumeCalculator.Business.BusinessLogic
{
    /// <summary>
    /// This is a helper class which will commute the volume
    /// </summary>
    public static class Helper
    {
        //•	Lateral dimension: 16 x 26
        //•	Lateral grid cell sizes: 200 x 200 feet!

        private static int GridWidth { get; set; }
        private static int GridLength { get; set; }
        private static int GridCellSize { get; set; }
        private static int BottomHorizonDifference { get; set; }
        private static int FluidContact { get; set; }

        public static ComputationResult ComputeVolume(ComputeCalculationRequest computeCalculationRequest)
        {
            var topDataPoints = CommonHelper.GetArrayFromDataPoints(computeCalculationRequest.FilePath ?? "");
            IntializeComponents(computeCalculationRequest);
            var bottomDataPoints = GetHorizonDataPoints(topDataPoints);

            var resultExcludingWater = CalculateDifferenceOfTopAndBottomHorizon(topDataPoints, bottomDataPoints);
            var resultBelowFluidContact = CalculateDifferenceOfFluidContact(topDataPoints, bottomDataPoints);
            var finalResult = Math.Abs(resultExcludingWater - resultBelowFluidContact);

            return new ComputationResult()
            {
                CubicFeetResult = finalResult.ToString(),
                BarrelResult = CommonHelper.ConvertToDifferentType(finalResult, "Barrel").ToString(),
                CubicMeterResult = CommonHelper.ConvertToDifferentType(finalResult, "CubicMeter").ToString(),
            };
        }

        private static void IntializeComponents(ComputeCalculationRequest computeCalculationRequest)
        {
            GridWidth = Convert.ToInt32(computeCalculationRequest.GridWidth);
            GridLength = Convert.ToInt32(computeCalculationRequest.GridLength);
            GridCellSize = Convert.ToInt32(computeCalculationRequest.GridCellLength) * Convert.ToInt32(computeCalculationRequest.GridCellWidth);
            BottomHorizonDifference = Convert.ToInt32(computeCalculationRequest.BottomHorizon);
            FluidContact = Convert.ToInt32(computeCalculationRequest.FluidContact);
        }

        private static double CalculateDifferenceOfTopAndBottomHorizon(double[,] topDataPoints, double[,] bottomDataPoints)
        {
            //Calculate Top Horizon

            var topHorizonVolume = GetVolume(topDataPoints) ?? 0;

            // Calculate Bottom Horizon volume
            var bottomHorizonVolume = GetVolume(bottomDataPoints) ?? 0;

            var result = Math.Abs(topHorizonVolume - bottomHorizonVolume);
            return result;
        }

        private static double CalculateDifferenceOfFluidContact(double[,] dataPoints, double[,] bottomDataPoints)
        {
            if (FluidContact <= 0) return 0;
            //get more than the fluidcontact data points
            var topHorizonPoints = GetFilteredDataPoints(dataPoints);
            var bottomHorizonPoints = GetFilteredDataPoints(bottomDataPoints);
            var result = CalculateDifferenceOfTopAndBottomHorizon(topHorizonPoints, bottomHorizonPoints);

            return result;
        }

        private static double? GetVolume(double[,] dataPoints)
        {
            double? volume = 0;
            // Calculate Volumne
            for (int i = 0; i < GridLength; i++)
            {
                for (int j = 0; j < GridWidth; j++)
                {
                    volume = volume + Convert.ToDouble(dataPoints[i, j]) * GridCellSize;
                }
            }

            return volume;
        }

        private static double[,] GetHorizonDataPoints(double[,] dataPoints)
        {
            var result = new double[GridLength, GridWidth];
            var convertedBottomValue = CommonHelper.ConvertToDifferentType(BottomHorizonDifference, "Feet");
            for (int i = 0; i < GridLength; i++)
            {
                for (int j = 0; j < GridWidth; j++)
                {
                    result[i, j] = dataPoints[i, j] + convertedBottomValue;
                }
            }

            return result;
        }

        private static double[,] GetFilteredDataPoints(double[,] dataPoints)
        {
            var result = new double[GridLength, GridWidth];
            var fluidContact = CommonHelper.ConvertToDifferentType(FluidContact, "Feet");
            for (int i = 0; i < GridLength; i++)
            {
                for (int j = 0; j < GridWidth; j++)
                {
                    result[i, j] = dataPoints[i, j] >= fluidContact ? dataPoints[i, j] : fluidContact;
                }
            }

            return result;
        }
    }
}