﻿namespace OilAndGasVolumeCalculator.Common.Interface
{
    /// <summary>
    /// This interface is created for custom exception.
    /// </summary>
    public interface ICustomException
    {
    }
}
