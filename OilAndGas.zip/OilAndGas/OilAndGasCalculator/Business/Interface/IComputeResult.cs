﻿using OilAndGasVolumeCalculator.Business.BusinessModel;
using OilAndGasVolumeCalculator.Controllers.Models;

namespace OilAndGasVolumeCalculator.Business.Interface
{
    /// <summary>
    /// This interface can compute the volume of oil and gas
    /// </summary>
    public interface IComputeResult
    {
        /// <summary>
        /// GetVolume calculates the volume
        /// <returns>An object of Computation result</returns>
        /// </summary>
        public ComputationResult GetVolume(ComputeCalculationRequest computeCalculationRequest);
    }
}
