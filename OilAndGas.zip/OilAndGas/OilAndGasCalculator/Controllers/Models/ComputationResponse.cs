﻿namespace OilAndGasVolumeCalculator.Controllers.Models
{
    public class ComputationResponse
    {
        public string? Result { get; set; }
    }
}
